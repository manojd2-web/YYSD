import React from 'react';
import Hero from '../components/Hero';
import { BookOpen, Users, Heart, Award, Target, Lightbulb } from 'lucide-react';

const HomePage = () => {
  return (
    <div>
      <Hero />
      
      {/* About Us Section */}
      <section id="about-us" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              About <span className="text-amber-800">Us</span>
            </h2>
            <div className="w-24 h-1 bg-amber-800 mx-auto mb-8"></div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <img
                src="/images/hero-pic.png"
                alt="Yogakshema Dhama"
                className="rounded-2xl shadow-lg w-full h-96 object-cover"
              />
            </div>
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-6">Our Sacred Mission</h3>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Yogakshema is a dedicated yoga institution founded by Shri Virupaksha Belavadi, envisioned as an abode for inner growth, well-being, and higher consciousness. Rooted in the timeless wisdom of Yoga, it aspires to guide individuals towards a holistic and spiritual lifestyle that nurtures the body, mind, and soul.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Located in Belavadi, a historical town once known as Ekachakra Nagara, the place carries deep cultural and mythological significance. It is believed to be where Bhima, the Pandava prince, slew the demon Bakasura, an event still remembered through the annual Bandi Utsava celebrated in the village.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Belavadi is also home to remarkable temples of great heritage - the magnificent Hoysala-era Trikutachala temple dedicated to Veeranarayana, and the sacred Udbhava Ganapathi temple, where Lord Ganesha has naturally manifested upon a stone. This village was given to the Sringeri Mutt by Mysuru Maharaja Krishnaraja Wodeyar in July 1828.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                The serene natural surroundings with the tranquil atmosphere, rustic flavour added, Belavadi serves as the perfect abode for the purpose for which the Dhama is envisioned. With such deep connect to significant events and the location advantages, Belavadi is chosen as the home for the Dhama.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center">
                  <BookOpen className="h-6 w-6 text-amber-800 mr-3" />
                  <span className="text-gray-700">25,000 sq ft Campus</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-6 w-6 text-amber-800 mr-3" />
                  <span className="text-gray-700">32 Residential Rooms</span>
                </div>
                <div className="flex items-center">
                  <Heart className="h-6 w-6 text-amber-800 mr-3" />
                  <span className="text-gray-700">2 Dedicated Yoga Halls</span>
                </div>
                <div className="flex items-center">
                  <Award className="h-6 w-6 text-amber-800 mr-3" />
                  <span className="text-gray-700">Surya Temple & Pyramid</span>
                </div>
              </div>
            </div>
          </div>

          {/* Values */}
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-amber-50 rounded-2xl">
              <Target className="h-12 w-12 text-amber-800 mx-auto mb-4" />
              <h4 className="text-xl font-bold text-gray-900 mb-3">Our Vision</h4>
              <p className="text-gray-700">To promote Yoga as a means of alternative healthcare and life management system.</p>
            </div>
            <div className="text-center p-6 bg-amber-50 rounded-2xl">
              <Heart className="h-12 w-12 text-amber-800 mx-auto mb-4" />
              <h4 className="text-xl font-bold text-gray-900 mb-3">Our Mission</h4>
              <p className="text-gray-700">To educate and make Yoga adaptable, affordable & easily accessible to all levels of people.</p>
            </div>
            <div className="text-center p-6 bg-amber-50 rounded-2xl">
              <Lightbulb className="h-12 w-12 text-amber-800 mx-auto mb-4" />
              <h4 className="text-xl font-bold text-gray-900 mb-3">Our Values</h4>
              <p className="text-gray-700">Holistic development through authentic yoga practices, environmental harmony, spiritual devotion, and compassionate care for all beings in our sacred community.</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Founder Section */}
      <section id="about-founder" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              About <span className="text-amber-800">Founder:</span>
            </h2>
            <div className="w-24 h-1 bg-amber-800 mx-auto mb-8"></div>
            <h3 className="text-3xl md:text-4xl font-bold text-amber-900 mb-8">
              Shri Virupaksha Belavadi
            </h3>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <p className="text-lg text-gray-800 leading-relaxed mb-6">
                Virupaksha Belavadi is a renowned Yoga Guru with over 27 years of 
                experience. He began his journey at the age of 18 under the tutelage of 
                reputed Yoga Gurus. He is credited with training more than 50,000 yoga 
                students and over 2000 yoga teachers worldwide.
              </p>
              <p className="text-lg text-gray-800 leading-relaxed mb-6">
                In 2013, he founded Yogakshema, an institute where his passion unfolds as 
                he conducts daily Yoga sessions for all age groups, both offline and online, 
                as well as a unique Yoga Teachers' training (YTT) course for Yoga 
                professionals. He extends his research into traditional Yoga and develops 
                innovative asanas using Iyengar Yoga props.
              </p>
              <p className="text-lg text-gray-800 leading-relaxed mb-6">
                He has been invited to organize workshops and deliver lectures at various 
                prestigious institutions such as ISRO, the Karnataka Civil Court, State Bank of India, and so on. His expertise is sought by Prison Authorities, and he has conducted 
                workshops at Bellary Central Jail for the benefit of its inmates.
              </p>
              <p className="text-lg text-gray-800 leading-relaxed mb-6">
                His exceptional contributions in the field of Yoga have been acknowledged 
                with numerous prestigious awards, including the Aryabhatta International 
                Award, the Naadabhushana Award, and the Mysuru Dasara Sanmaana.
              </p>
              <p className="text-lg text-gray-800 leading-relaxed mb-6">
                He is a prolific writer and has authored several books on Yoga and allied 
                subjects. He is a regular columnist in a popular Kannada daily, "Vijaya Karnataka" which has resonated with a wide readership.
              </p>

              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-white rounded-xl shadow-md">
                  <div className="text-2xl font-bold text-amber-800 mb-1">27+</div>
                  <div className="text-gray-600 text-sm">Years of Practice</div>
                </div>
                <div className="text-center p-4 bg-white rounded-xl shadow-md">
                  <div className="text-2xl font-bold text-amber-800 mb-1">50,000+</div>
                  <div className="text-gray-600 text-sm">Students Trained</div>
                </div>
                <div className="text-center p-4 bg-white rounded-xl shadow-md">
                  <div className="text-2xl font-bold text-amber-800 mb-1">2000+</div>
                  <div className="text-gray-600 text-sm">Teachers Trained</div>
                </div>
                <div className="text-center p-4 bg-white rounded-xl shadow-md">
                  <div className="text-2xl font-bold text-amber-800 mb-1">2013</div>
                  <div className="text-gray-600 text-sm">Founded Yogakshema</div>
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <img
                src="https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg"
                alt="Shri Virupaksha Belavadi"
                className="rounded-2xl shadow-lg w-full h-96 object-cover bg-gradient-to-br from-amber-100 to-orange-100 p-8"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;