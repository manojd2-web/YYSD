import React from 'react';
import { MapPin, Phone, Mail, Users, Building, GraduationCap } from 'lucide-react';

const CentersPage = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-teal-800 via-cyan-700 to-teal-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Our Centers</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Discover our network of yoga centers spreading authentic teachings across regions
          </p>
        </div>
      </section>

      {/* Main Center Section */}
      <section id="main-center" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Main Center <span className="text-teal-600">(Belavadi)</span>
            </h2>
            <div className="w-24 h-1 bg-teal-600 mx-auto mb-8"></div>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <img
                src="https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg"
                alt="Main Center Belavadi"
                className="rounded-2xl shadow-lg w-full h-96 object-cover"
              />
            </div>
            <div>
              <div className="flex items-center mb-6">
                <Building className="h-8 w-8 text-teal-600 mr-4" />
                <h3 className="text-3xl font-bold text-gray-900">Belavadi Main Centre</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Our main center in Belavadi serves as the headquarters of YOGAKSHEMA YOGA SAADHANA DHAMA. 
                This is where our founder established the original dhama, complete with all facilities 
                including the Surya Temple, goshala, pyramid meditation center, and residential quarters.
              </p>
              
              <div className="space-y-4 mb-6">
                <div className="flex items-start">
                  <MapPin className="h-5 w-5 text-teal-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-gray-900">Address</p>
                    <p className="text-gray-700">Near Vaddarahalli Gate, Belavadi Village, Lakya Hobli, Chikkamagalur District, PIN code: 577146, Karnataka, India</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Phone className="h-5 w-5 text-teal-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-gray-900">Contact</p>
                    <p className="text-gray-700">+91 8762038295 / +91 9945113269 / +91 8861102398</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Mail className="h-5 w-5 text-teal-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-gray-900">Email</p>
                    <p className="text-gray-700">belavadi@yogakshema.org</p>
                  </div>
                </div>
              </div>

              <div className="bg-teal-50 rounded-2xl p-6 mb-6">
                <h4 className="font-bold text-gray-900 mb-4">Class Timings:</h4>
                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <p className="font-semibold text-teal-800">Morning Classes:</p>
                    <p className="text-gray-700 text-sm">Contact for timings</p>
                  </div>
                  <div>
                    <p className="font-semibold text-teal-800">Evening Classes:</p>
                    <p className="text-gray-700 text-sm">Contact for timings</p>
                  </div>
                </div>
              </div>

              <div className="bg-teal-50 rounded-2xl p-6">
                <h4 className="font-bold text-gray-900 mb-4">Main Center Features:</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-700">Sacred Dhama Complex</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-700">Surya Temple</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-700">Goshala (Cow Sanctuary)</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-700">Pyramid Meditation Center</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-700">Sacred Walking Paths</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-teal-600 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-700">Residential Facilities</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Google Map for Main Center */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Locate Us</h3>
            <div className="bg-gray-200 rounded-2xl h-96 flex items-center justify-center">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.8267!2d75.8577!3d13.1986!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTPCsDExJzU1LjAiTiA3NcKwNTEnMjcuNyJF!5e0!3m2!1sen!2sin!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0, borderRadius: '1rem' }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Belavadi Main Centre Location"
              ></iframe>
            </div>
          </div>
        </div>
      </section>

      {/* Bengaluru Centers Section */}
      <section id="bengaluru" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-blue-600">Bengaluru</span> Centers
            </h2>
            <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12">
            {[
              {
                name: 'Nagarbhavi Centre',
                address: '#116, Sri Raksha, 10th Cross Rd, 2nd Main NGEF Layout, Nagarbhavi, Bengaluru, Karnataka 560072',
                contact: '+91 8762038295 / +91 9945113269 / +91 8861102398',
                morningClasses: 'Contact for timings',
                eveningClasses: 'Contact for timings',
                mapSrc: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.8267!2d77.5385!3d12.9716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTPCsDExJzU1LjAiTiA3NcKwNTEnMjcuNyJF!5e0!3m2!1sen!2sin!4v1234567890'
              },
              {
                name: 'Rajajinagar Centre',
                address: 'Shop No. 1, 6th Main Road 10th Main Road, Shivanagar, Rajajinagar, Bengaluru, Karnataka 560010',
                contact: '+91 8762038295 / +91 9945113269 / +91 8861102398',
                morningClasses: '6:00am to 7:00am / 7:00am to 8:00am',
                eveningClasses: '5:00pm to 6:00pm / 6:00pm to 7:00pm',
                mapSrc: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.8267!2d77.5385!3d12.9716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTPCsDExJzU1LjAiTiA3NcKwNTEnMjcuNyJF!5e0!3m2!1sen!2sin!4v1234567890'
              }
            ].map((center, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
                <div className="flex items-center mb-4">
                  <Building className="h-6 w-6 text-blue-600 mr-3" />
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{center.name}</h3>
                  </div>
                </div>
                
                <div className="space-y-4 mb-6">
                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 text-blue-600 mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-gray-900">Address</p>
                      <p className="text-gray-700 text-sm">{center.address}</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Phone className="h-5 w-5 text-blue-600 mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-gray-900">Contact</p>
                      <p className="text-gray-700 text-sm">{center.contact}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 rounded-2xl p-6 mb-6">
                  <h4 className="font-bold text-gray-900 mb-4">Class Timings:</h4>
                  <div className="grid grid-cols-1 gap-3">
                    <div>
                      <p className="font-semibold text-blue-800">Morning Classes:</p>
                      <p className="text-gray-700 text-sm">{center.morningClasses}</p>
                    </div>
                    <div>
                      <p className="font-semibold text-blue-800">Evening Classes:</p>
                      <p className="text-gray-700 text-sm">{center.eveningClasses}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-gray-900 mb-4">Locate Us:</h4>
                  <div className="bg-gray-200 rounded-xl h-64">
                    <iframe
                      src={center.mapSrc}
                      width="100%"
                      height="100%"
                      style={{ border: 0, borderRadius: '0.75rem' }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      title={`${center.name} Location`}
                    ></iframe>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Student Centers Section */}
      <section id="student-centers" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Centres run by <span className="text-green-600">our students</span>
            </h2>
            <div className="w-24 h-1 bg-green-600 mx-auto mb-8"></div>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Our dedicated students have established centers across India and internationally, 
              spreading authentic yoga teachings in their communities.
            </p>
          </div>
          
          {/* Locate Centres Map */}
          <div className="bg-green-50 rounded-2xl p-8 mb-16">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Locate Centres</h3>
            <div className="bg-gray-200 rounded-2xl h-96">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.8267!2d77.5385!3d12.9716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTPCsDExJzU1LjAiTiA3NcKwNTEnMjcuNyJF!5e0!3m2!1sen!2sin!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0, borderRadius: '1rem' }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Student Centres Locations"
              ></iframe>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CentersPage;