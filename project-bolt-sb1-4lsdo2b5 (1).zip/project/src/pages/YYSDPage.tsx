import React from 'react';
import { useState } from 'react';
import { Building2, Sun, Cog as Cow, Triangle, TreePine, BookOpen, Users } from 'lucide-react';

const YYSDPage = () => {
  const [activeTab, setActiveTab] = useState('offerings');

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-amber-800 via-orange-700 to-amber-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">YYSD Facilities</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Explore our sacred spaces and spiritual facilities designed for your inner journey
          </p>
        </div>
      </section>

      {/* Dhama Section */}
      <section id="dhama" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Sacred <span className="text-amber-600">Dhama</span>
            </h2>
            <div className="w-24 h-1 bg-amber-600 mx-auto mb-8"></div>
          </div>
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg"
                alt="Sacred Dhama"
                className="rounded-2xl shadow-lg w-full h-96 object-cover"
              />
            </div>
            <div>
              <div className="flex items-center mb-6">
                <Building2 className="h-8 w-8 text-amber-600 mr-4" />
                <h3 className="text-3xl font-bold text-gray-900">Dhama</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Yogakshema Yoga Saadana Dhāma is nestled in the heart of nature, surrounded by serene greenery and fresh air, far away from the bustle of city life, making it a rejuvenating retreat for both body and mind.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Spread across 25,000 square feet, this residential Yoga Centre is thoughtfully designed to nurture physical well-being and inner transformation. The centre's main attraction is its two spacious Yoga Halls, exclusively dedicated to programs curated by our Founder, Shri Virupaksha Belavadi.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                The Dhāma also houses 32 well-equipped rooms for yoga learners, enthusiasts, donors, and visitors, along with a dining hall and kitchen, a dedicated office, a library, and staff quarters.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Adding to the holistic experience is the Bhojana Shāle in this Dhama, which serves authentic and wholesome desi food, prepared with care to nourish both body and spirit. Visitors also have the opportunity to be part of the Annadāna scheme, through which free meals are offered with devotion and inclusivity.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                The location of Yogakshema further enriches its spiritual aura, as it is in close proximity to some of Karnataka's finest cultural and architectural heritage sites, including the Hoysala temples of Halebeedu and Belur, as well as the magnificent Belavadi Veeranarayana Temple.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                With its blend of yoga, spirituality, tradition, and heritage, Yogakshema Yoga Sādana Dhāma stands as an abode for seekers of wellness and consciousness.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Two spacious Yoga Halls for dedicated programs</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">32 well-equipped residential rooms</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Bhojana Shāle serving authentic desi food</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Annadāna scheme for free meals with devotion</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Surya Temple Section */}
      <section id="temple" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-orange-600">Surya</span> Temple
            </h2>
            <div className="w-24 h-1 bg-orange-600 mx-auto mb-8"></div>
          </div>
          <div className="grid lg:grid-cols-3 gap-8 items-start">
            <div className="order-2 lg:order-1">
              <div className="flex items-center mb-6">
                <Sun className="h-8 w-8 text-orange-600 mr-4" />
                <h3 className="text-3xl font-bold text-gray-900">Temple of Solar Energy</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                The Sun God is one of twelve sons born to Aditi and Kashyapa, collectively known as the Dvadasha Bhaskaras. Temples dedicated to these twelve forms of the Sun can be found in Kashi. The Sun God has three wives (Ushadevi, Sanyadevi, and Chhayadevi) and two daughters (Yamuna and Tapati). His sons are Yama, Vaivasvatamanu, Shani, Sauparnikamanu, and the Ashwini Devas.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Considered the ruler of the universe, the Sun God is also the lord of the solar system, the nine planets, astrology, architecture, and health. This is why the saying goes: "ārogyaṁ bhāskarādiccheth" (meaning "Health comes from the Sun").
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                This temple has a four feet high pedestal, which represents the universe. It features four wheels, which represent the four yugas; 12 pillars, which represent the 12 Bhaskaras; and two pillars at the main gate, which represent Uttarayana and Dakshinayana. The sanctum sanctorum represents the Sun's world, while the three towers above symbolize the three wives of Surya.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                In front of the temple, there are 7 horses, symbolizing the 7 chakras in a human being. The 7 snakes, which act as the ropes tied to control the horses, represent the 7 major nadis in a human being that give supernatural power.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Aruna Deva, who drives the chariot, resides here as the soul that drives this body, while Lord Suryadeva dwells in the sanctum sanctorum as the Supreme Soul. This magnificent and deeply symbolic temple honors the Sun, the source of all life and sustenance. May this temple bring Suryadeva's divine grace to all who seek it.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-orange-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Sacred architecture representing cosmic principles</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-orange-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Symbolic elements representing chakras and nadis</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-orange-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Daily sunrise and sunset prayer ceremonies</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-orange-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Solar meditation and divine grace practices</span>
                </li>
              </ul>
            </div>
            <div className="order-1 lg:order-2">
              <img
                src="https://images.pexels.com/photos/3992828/pexels-photo-3992828.jpeg"
                alt="Surya Temple"
                className="rounded-2xl shadow-lg w-full h-96 object-cover"
              />
            </div>
            
            {/* Side Tabs */}
            <div className="order-3 lg:order-3">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                {/* Tab Headers */}
                <div className="flex border-b border-gray-200">
                  <button
                    onClick={() => setActiveTab('offerings')}
                    className={`flex-1 py-4 px-6 text-sm font-semibold transition-colors ${
                      activeTab === 'offerings'
                        ? 'bg-orange-600 text-white'
                        : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    Offerings
                  </button>
                  <button
                    onClick={() => setActiveTab('events')}
                    className={`flex-1 py-4 px-6 text-sm font-semibold transition-colors ${
                      activeTab === 'events'
                        ? 'bg-orange-600 text-white'
                        : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    Events
                  </button>
                </div>
                
                {/* Tab Content */}
                <div className="p-6">
                  {activeTab === 'offerings' && (
                    <div className="space-y-6">
                      <h4 className="text-xl font-bold text-gray-900 mb-4">Temple Offerings</h4>
                      
                      <div className="space-y-4">
                        <div className="border-l-4 border-orange-600 pl-4">
                          <h5 className="font-semibold text-gray-900 mb-2">Surya Puja</h5>
                          <p className="text-sm text-gray-700 mb-2">Complete worship ritual with flowers, incense, and sacred chants</p>
                          <p className="text-orange-600 font-semibold text-sm">₹501</p>
                        </div>
                        
                        <div className="border-l-4 border-orange-600 pl-4">
                          <h5 className="font-semibold text-gray-900 mb-2">Abhishekam</h5>
                          <p className="text-sm text-gray-700 mb-2">Sacred bathing ceremony with milk, honey, and holy water</p>
                          <p className="text-orange-600 font-semibold text-sm">₹1,001</p>
                        </div>
                        
                        <div className="border-l-4 border-orange-600 pl-4">
                          <h5 className="font-semibold text-gray-900 mb-2">Homa/Yagna</h5>
                          <p className="text-sm text-gray-700 mb-2">Fire ceremony for health, prosperity, and spiritual purification</p>
                          <p className="text-orange-600 font-semibold text-sm">₹2,501</p>
                        </div>
                        
                        <div className="border-l-4 border-orange-600 pl-4">
                          <h5 className="font-semibold text-gray-900 mb-2">Pradakshina</h5>
                          <p className="text-sm text-gray-700 mb-2">Circumambulation with guided meditation and mantras</p>
                          <p className="text-orange-600 font-semibold text-sm">₹101</p>
                        </div>
                        
                        <div className="border-l-4 border-orange-600 pl-4">
                          <h5 className="font-semibold text-gray-900 mb-2">Sankalpa Puja</h5>
                          <p className="text-sm text-gray-700 mb-2">Special intention-setting ceremony for personal goals</p>
                          <p className="text-orange-600 font-semibold text-sm">₹751</p>
                        </div>
                      </div>
                      
                      <div className="bg-orange-50 rounded-lg p-4 mt-6">
                        <p className="text-sm text-orange-800">
                          <strong>Note:</strong> All offerings include prasadam and can be performed on behalf of family members. 
                          Contact us to schedule your preferred time.
                        </p>
                      </div>
                    </div>
                  )}
                  
                  {activeTab === 'events' && (
                    <div className="space-y-6">
                      <h4 className="text-xl font-bold text-gray-900 mb-4">Temple Events</h4>
                      
                      <div className="space-y-4">
                        <div className="bg-orange-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-semibold text-gray-900">Daily Surya Aarti</h5>
                            <span className="text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded-full">Daily</span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">Morning and evening prayers with devotional songs</p>
                          <p className="text-orange-600 text-sm font-medium">6:00 AM & 6:30 PM</p>
                        </div>
                        
                        <div className="bg-orange-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-semibold text-gray-900">Surya Jayanti</h5>
                            <span className="text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded-full">Annual</span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">Grand celebration of Sun God's birth with special ceremonies</p>
                          <p className="text-orange-600 text-sm font-medium">February (Magha Saptami)</p>
                        </div>
                        
                        <div className="bg-orange-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-semibold text-gray-900">Chhath Puja</h5>
                            <span className="text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded-full">Annual</span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">Four-day festival dedicated to Sun God and Chhathi Maiya</p>
                          <p className="text-orange-600 text-sm font-medium">October/November</p>
                        </div>
                        
                        <div className="bg-orange-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-semibold text-gray-900">Makar Sankranti</h5>
                            <span className="text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded-full">Annual</span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">Celebration of Sun's transition to Capricorn with special rituals</p>
                          <p className="text-orange-600 text-sm font-medium">January 14th</p>
                        </div>
                        
                        <div className="bg-orange-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-semibold text-gray-900">Solar Eclipse Prayers</h5>
                            <span className="text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded-full">Special</span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">Special protective prayers and rituals during solar eclipses</p>
                          <p className="text-orange-600 text-sm font-medium">As per astronomical calendar</p>
                        </div>
                      </div>
                      
                      <div className="bg-orange-50 rounded-lg p-4 mt-6">
                        <p className="text-sm text-orange-800">
                          <strong>Participation:</strong> All events are open to devotees. Special arrangements can be made for group participation. 
                          Contact us for event schedules and participation details.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Temple Features */}
          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="text-center p-6 bg-orange-50 rounded-2xl">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sun className="h-8 w-8 text-orange-600" />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-3">Yagna Mantapa</h4>
              <p className="text-gray-700">A sacred space for Yagna (Homa) rituals and offerings, the Yagna Mantapa symbolizes divine connection and the purification of body, mind, and soul. It is where sacred chants invoke universal harmony.</p>
            </div>
            <div className="text-center p-6 bg-orange-50 rounded-2xl">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="w-8 h-8 rounded-full border-4 border-orange-600 flex items-center justify-center">
                  <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                </div>
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-3">Kalyani (Sacred Pond)</h4>
              <p className="text-gray-700">The Kalyani represents purity and renewal, offering devotees a serene place for reflection and spiritual cleansing before entering the divine sanctum.</p>
            </div>
            <div className="text-center p-6 bg-orange-50 rounded-2xl">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="w-8 h-8 text-orange-600 font-bold text-lg flex items-center justify-center">A</div>
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-3">Arun Yogiraj</h4>
              <p className="text-gray-700">Renowned sculptor Arun Yogiraj, creator of the majestic Surya Deva murti at Yogakshema Dhama, is revered here for his divine craftsmanship that transforms stone into spirit and inspires countless devotees.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Goshala Section */}
      <section id="goshaale" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-green-600">Gokulam Goshale</span>
            </h2>
            <div className="w-24 h-1 bg-green-600 mx-auto mb-8"></div>
          </div>
          <div className="grid lg:grid-cols-3 gap-8 items-start">
            <div>
              <img
                src="https://images.pexels.com/photos/422218/pexels-photo-422218.jpeg"
                alt="Gokulam Goshale"
                className="rounded-2xl shadow-lg w-full h-96 object-cover"
              />
            </div>
            <div>
              <div className="flex items-center mb-6">
                <Cow className="h-8 w-8 text-green-600 mr-4" />
                <h3 className="text-3xl font-bold text-gray-900">Gokulam Goshale</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                In Bharatiya culture, every house should have a cow as a shubha lakshana. Compulsory in ashrama. In this prakaara we have a goshala. It is not just a cowshed, but a bhakti emotion of the temple.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                A Goshaale will be constructed alongside the temple. Come and be a part of the home to give your love and affection to the various desi (indigenous) cow breeds.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Our Gokulam Goshaale is envisioned with Lord Krishna standing on Govardhana Hill, playing the flute, while cows form a graceful semicircle facing Him.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                As devotees perform pradakshina, they receive the divine blessings of both Krishna and gomata, evoking a deeply spiritual experience.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Sustainable of Goutpanna
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Your presence and support will help nurture and protect these sacred beings.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-green-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Lord Krishna with cows in graceful semicircle</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-green-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Divine blessings through pradakshina</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-green-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Home for various desi cow breeds</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-green-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Bhakti emotion and spiritual experience</span>
                </li>
              </ul>
            </div>
            
            {/* Goshaale Side Tabs */}
            <div>
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                {/* Tab Headers */}
                <div className="flex border-b border-gray-200">
                  <button
                    onClick={() => setActiveTab('services')}
                    className={`flex-1 py-4 px-6 text-sm font-semibold transition-colors ${
                      activeTab === 'services'
                        ? 'bg-green-600 text-white'
                        : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    Services
                  </button>
                  <button
                    onClick={() => setActiveTab('goshala-offerings')}
                    className={`flex-1 py-4 px-6 text-sm font-semibold transition-colors ${
                      activeTab === 'goshala-offerings'
                        ? 'bg-green-600 text-white'
                        : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    Offerings
                  </button>
                </div>
                
                {/* Tab Content */}
                <div className="p-6">
                  {activeTab === 'services' && (
                    <div className="space-y-6">
                      <h4 className="text-xl font-bold text-gray-900 mb-4">Gokulam Goshale Services</h4>
                      
                      <div className="space-y-4">
                        <div className="border-l-4 border-green-600 pl-4">
                          <h5 className="font-semibold text-gray-900 mb-2">Cow Donations</h5>
                          <p className="text-sm text-gray-700 mb-2">Support our sacred cows with monthly or one-time donations</p>
                          <div className="space-y-1">
                            <p className="text-green-600 font-semibold text-sm">Monthly: ₹1,500</p>
                            <p className="text-green-600 font-semibold text-sm">Yearly: ₹15,000</p>
                            <p className="text-green-600 font-semibold text-sm">One-time: ₹5,000+</p>
                          </div>
                        </div>
                        
                        <div className="border-l-4 border-green-600 pl-4">
                          <h5 className="font-semibold text-gray-900 mb-2">Cow Adoption</h5>
                          <p className="text-sm text-gray-700 mb-2">Adopt a cow and receive regular updates on their well-being</p>
                          <div className="space-y-1">
                            <p className="text-green-600 font-semibold text-sm">Full Adoption: ₹25,000/year</p>
                            <p className="text-green-600 font-semibold text-sm">Partial Adoption: ₹12,000/year</p>
                            <p className="text-green-600 font-semibold text-sm">Includes: Photos, updates, naming rights</p>
                          </div>
                        </div>
                        
                        <div className="border-l-4 border-green-600 pl-4">
                          <h5 className="font-semibold text-gray-900 mb-2">Medical Care Fund</h5>
                          <p className="text-sm text-gray-700 mb-2">Contribute to veterinary care and medical treatments</p>
                          <p className="text-green-600 font-semibold text-sm">₹2,500 - ₹10,000</p>
                        </div>
                        
                        <div className="border-l-4 border-green-600 pl-4">
                          <h5 className="font-semibold text-gray-900 mb-2">Fodder Sponsorship</h5>
                          <p className="text-sm text-gray-700 mb-2">Sponsor organic fodder and nutritious feed for the cows</p>
                          <p className="text-green-600 font-semibold text-sm">₹3,000/month per cow</p>
                        </div>
                        
                        <div className="border-l-4 border-green-600 pl-4">
                          <h5 className="font-semibold text-gray-900 mb-2">Shelter Maintenance</h5>
                          <p className="text-sm text-gray-700 mb-2">Support infrastructure and shelter improvements</p>
                          <p className="text-green-600 font-semibold text-sm">₹5,000 - ₹50,000</p>
                        </div>
                      </div>
                      
                      <div className="bg-green-50 rounded-lg p-4 mt-6">
                        <p className="text-sm text-green-800">
                          <strong>Benefits:</strong> All donors receive certificates, regular updates, and blessings. 
                          Visit anytime to see your contribution in action.
                        </p>
                      </div>
                    </div>
                  )}
                  
                  {activeTab === 'goshala-offerings' && (
                    <div className="space-y-6">
                      <h4 className="text-xl font-bold text-gray-900 mb-4">Sacred Offerings</h4>
                      
                      <div className="space-y-4">
                        <div className="bg-green-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-semibold text-gray-900">Gopuja (Cow Worship)</h5>
                            <span className="text-xs bg-green-200 text-green-800 px-2 py-1 rounded-full">Sacred</span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">Traditional cow worship ceremony with flowers, prayers, and offerings</p>
                          <p className="text-green-600 text-sm font-medium">₹501 - ₹2,501</p>
                        </div>
                        
                        <div className="bg-green-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-semibold text-gray-900">Gau Mata Abhishekam</h5>
                            <span className="text-xs bg-green-200 text-green-800 px-2 py-1 rounded-full">Blessing</span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">Sacred bathing ceremony for cows with milk, turmeric, and holy water</p>
                          <p className="text-green-600 text-sm font-medium">₹1,001 - ₹5,001</p>
                        </div>
                        
                        <div className="bg-green-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-semibold text-gray-900">Gau Daan</h5>
                            <span className="text-xs bg-green-200 text-green-800 px-2 py-1 rounded-full">Merit</span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">Sacred act of gifting a cow - highest form of charity in Hindu tradition</p>
                          <p className="text-green-600 text-sm font-medium">₹51,000 - ₹1,51,000</p>
                        </div>
                        
                        <div className="bg-green-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-semibold text-gray-900">Kamadhenu Puja</h5>
                            <span className="text-xs bg-green-200 text-green-800 px-2 py-1 rounded-full">Divine</span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">Worship of the divine cow Kamadhenu for fulfillment of wishes</p>
                          <p className="text-green-600 text-sm font-medium">₹2,501 - ₹11,000</p>
                        </div>
                        
                        <div className="bg-green-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-semibold text-gray-900">Gau Seva</h5>
                            <span className="text-xs bg-green-200 text-green-800 px-2 py-1 rounded-full">Service</span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">Personal service to cows including feeding, cleaning, and care</p>
                          <p className="text-green-600 text-sm font-medium">₹251 - ₹1,001</p>
                        </div>
                        
                        <div className="bg-green-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-semibold text-gray-900">Panchagavya Preparation</h5>
                            <span className="text-xs bg-green-200 text-green-800 px-2 py-1 rounded-full">Healing</span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">Sacred preparation using five cow products for spiritual and health benefits</p>
                          <p className="text-green-600 text-sm font-medium">₹501 - ₹2,001</p>
                        </div>
                      </div>
                      
                      <div className="bg-green-50 rounded-lg p-4 mt-6">
                        <p className="text-sm text-green-800">
                          <strong>Sacred Benefits:</strong> All offerings include prasadam, blessings, and spiritual merit. 
                          Participate in person or sponsor remotely with photo/video updates.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pyramid Section */}
      <section id="pyramid" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-purple-600">Pyramid - Shree Maa Dhyana Mandira</span>
            </h2>
            <div className="w-24 h-1 bg-purple-600 mx-auto mb-8"></div>
          </div>
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="flex items-center mb-6">
                <Triangle className="h-8 w-8 text-purple-600 mr-4" />
                <h3 className="text-3xl font-bold text-gray-900">Shree Maa Dhyana Mandira</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Our Pyramid – Shree Maa Dhyana Mandira is uniquely designed as a sacred space dedicated to meditation and inner stillness, with its structure channelizing cosmic energy for spiritual upliftment. At its heart, a consecrated Shree Chakra is installed, radiating divine vibrations and bestowing prosperity, harmony, and well-being upon all who meditate within.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                The pyramid's tranquil ambiance, combined with its powerful geometric and spiritual symbolism, creates an ideal environment for seekers to experience deep focus, energy alignment, and divine grace. Pyramid will have navagraha plants surrounding it.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-purple-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Consecrated Shree Chakra radiating divine vibrations</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-purple-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Cosmic energy channelization for spiritual upliftment</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-purple-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Navagraha plants surrounding the pyramid</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-purple-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Sacred geometry for deep focus and divine grace</span>
                </li>
              </ul>
            </div>
            <div className="order-1 lg:order-2">
              <img
                src="https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg"
                alt="Pyramid - Shree Maa Dhyana Mandira"
                className="rounded-2xl shadow-lg w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Walking Path Section */}
      <section id="walking" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-emerald-600">Healing Walkway</span>
            </h2>
            <div className="w-24 h-1 bg-emerald-600 mx-auto mb-8"></div>
          </div>
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.pexels.com/photos/1051838/pexels-photo-1051838.jpeg"
                alt="Sacred Walking Path"
                className="rounded-2xl shadow-lg w-full h-96 object-cover"
              />
            </div>
            <div>
              <div className="flex items-center mb-6">
                <TreePine className="h-8 w-8 text-emerald-600 mr-4" />
                <h3 className="text-3xl font-bold text-gray-900">Healing Walkway</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                The project features a walking path encircling the premises, thoughtfully designed with varied surfaces including pebbles, sand, clay, water, and grass to stimulate acupressure points and promote overall wellness. As visitors stroll along, they are enveloped in a serene atmosphere enhanced by soothing music and sacred mantras, creating a holistic experience that nurtures both body and mind, encouraging relaxation, balance, and rejuvenation.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-emerald-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Varied surfaces: pebbles, sand, clay, water, and grass</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-emerald-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Acupressure point stimulation for wellness</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-emerald-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Soothing music and sacred mantras</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-emerald-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Holistic experience for body and mind wellness</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section id="yttc" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-blue-600">Yoga Teachers Training Camps</span> (YTTC)
            </h2>
            <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          </div>
          
          {/* YTTC Introduction */}
          <div className="bg-white rounded-2xl p-8 shadow-lg mb-16">
            <div className="flex items-center mb-6">
              <BookOpen className="h-8 w-8 text-blue-600 mr-4" />
              <h3 className="text-3xl font-bold text-gray-900">Yoga Teachers Training Camps (YTTC)</h3>
            </div>
            <p className="text-lg text-gray-700 leading-relaxed mb-8">
              One of the primary goals of establishing the Dhama is to train and dedicate Yoga teachers to the community who can spread wellness among the masses. Workshops and Skill Development camps are organized for Yoga teachers to continuously upgrade their skills and achieve mastery.
            </p>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { title: 'Meditation Course', description: 'Deep meditation practices and techniques' },
                { title: 'Pranayama Course', description: 'Advanced breathing techniques and practices' },
                { title: 'Therapy Course', description: 'Therapeutic applications of yoga' },
                { title: 'Workshop for Yoga Teachers', description: 'Professional development for instructors' },
                { title: 'Sanskrit Coaching', description: 'Traditional language and chanting' },
                { title: 'Personality Development Course', description: 'Holistic personal growth and development' }
              ].map((course, index) => (
                <div key={index} className="bg-blue-50 rounded-xl p-6 hover:shadow-md transition-all duration-300">
                  <h4 className="text-lg font-bold text-gray-900 mb-2">{course.title}</h4>
                  <p className="text-gray-700 text-sm">{course.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Activities Section */}
          <div className="bg-white rounded-2xl p-8 shadow-lg mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">Activities</h3>
            
            <div className="space-y-8">
              {/* Yoga Instruction Sessions */}
              <div className="border-l-4 border-blue-600 pl-6">
                <h4 className="text-xl font-bold text-gray-900 mb-4">Yoga Instruction Sessions</h4>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Both online and offline sessions are conducted for the benefit of students across the globe. Online sessions are conducted for the benefit of students across the globe. Offline Sessions at Belavadi include Regular and Customized Sessions. Customized sessions are tailored to the specific needs of residents/visitors to the Dhama, including corporate groups and individuals seeking weekend or weeklong retreats, designed to revitalize mind, body, and spirit.
                </p>
              </div>

              {/* Meditation and Pranayama Camp */}
              <div className="border-l-4 border-blue-600 pl-6">
                <h4 className="text-xl font-bold text-gray-900 mb-4">Meditation and Pranayama Camp</h4>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Present day world demands a high level of attention, concentration and awareness both physically & mentally to lead a fulfilling life. Keeping this in mind, various types of Pranayama and Meditation techniques are taught with utmost care & personal guidance.
                </p>
              </div>

              {/* Other Activities */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-blue-50 rounded-xl p-6">
                  <h4 className="text-lg font-bold text-gray-900 mb-3">Yoga Retreats</h4>
                  <p className="text-gray-700 text-sm">Immersive retreat experiences for deep spiritual practice and rejuvenation.</p>
                </div>
                <div className="bg-blue-50 rounded-xl p-6">
                  <h4 className="text-lg font-bold text-gray-900 mb-3">Cultural and Spiritual Programs</h4>
                  <p className="text-gray-700 text-sm">Bhajans, lecture series, and other spiritual gatherings.</p>
                </div>
                <div className="bg-blue-50 rounded-xl p-6">
                  <h4 className="text-lg font-bold text-gray-900 mb-3">Shivaratri</h4>
                  <p className="text-gray-700 text-sm">Special celebrations including Nagasadhu ceremonies.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Accommodation Section */}
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">Accommodation</h3>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-blue-50 rounded-xl p-8 text-center hover:shadow-md transition-all duration-300">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-3">Twin Sharing Rooms</h4>
                <p className="text-gray-700">Comfortable twin sharing accommodation for a peaceful stay during your training programs.</p>
              </div>
              
              <div className="bg-blue-50 rounded-xl p-8 text-center hover:shadow-md transition-all duration-300">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Building2 className="h-8 w-8 text-blue-600" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-3">Dormitory - 6 People</h4>
                <p className="text-gray-700">Shared dormitory accommodation for groups, fostering community spirit and fellowship.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default YYSDPage;