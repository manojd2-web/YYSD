import React from 'react';
import { Calendar, Clock, Users, MapPin, Star } from 'lucide-react';

const EventsPage = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-purple-800 via-indigo-700 to-purple-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Spiritual Events</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Join our regular spiritual gatherings, ceremonies, and special celebrations
          </p>
        </div>
      </section>

      {/* Upcoming Events Section */}
      <section id="upcoming" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-green-600">Upcoming</span> Events
            </h2>
            <div className="w-24 h-1 bg-green-600 mx-auto mb-8"></div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {/* Arivu Program */}
            <div className="bg-green-50 rounded-2xl p-8 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center mb-4">
                <Star className="h-8 w-8 text-green-600 mr-3" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Arivu Program</h3>
                  <p className="text-green-600 font-semibold">Educational Initiative</p>
                </div>
              </div>
              <p className="text-gray-700 mb-6">
                A comprehensive educational program designed to enhance knowledge and awareness 
                through traditional wisdom and modern understanding. Join us for this 
                transformative learning experience.
              </p>
              <div className="space-y-3 mb-6">
                <div className="flex items-center text-gray-600">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>Date: To be announced</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Clock className="h-4 w-4 mr-2" />
                  <span>Duration: Full day program</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span>Venue: Yogakshema Dhama</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Users className="h-4 w-4 mr-2" />
                  <span>Open to all participants</span>
                </div>
              </div>
              <button className="w-full bg-green-600 text-white py-3 rounded-full hover:bg-green-700 transition-colors font-semibold">
                Register Interest
              </button>
            </div>

            {/* Ratha Sapthami Inauguration */}
            <div className="bg-green-50 rounded-2xl p-8 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center mb-4">
                <Star className="h-8 w-8 text-green-600 mr-3" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Ratha Sapthami Inauguration</h3>
                  <p className="text-green-600 font-semibold">Sacred Ceremony</p>
                </div>
              </div>
              <p className="text-gray-700 mb-6">
                Join us for the sacred inauguration ceremony of Ratha Sapthami, celebrating 
                the Sun God's journey and the victory of light over darkness. A spiritually 
                uplifting ceremony with traditional rituals and prayers.
              </p>
              <div className="space-y-3 mb-6">
                <div className="flex items-center text-gray-600">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>Date: To be announced</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Clock className="h-4 w-4 mr-2" />
                  <span>Time: Early morning ceremony</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span>Venue: Surya Temple, Yogakshema Dhama</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Users className="h-4 w-4 mr-2" />
                  <span>Community gathering</span>
                </div>
              </div>
              <button className="w-full bg-green-600 text-white py-3 rounded-full hover:bg-green-700 transition-colors font-semibold">
                Register Interest
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Past Events Section */}
      <section id="past" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-blue-600">Past</span> Events
            </h2>
            <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {/* Arivu Program - Past Event */}
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="flex items-center mb-4">
                <Star className="h-8 w-8 text-blue-600 mr-3" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Arivu Program</h3>
                  <p className="text-blue-600 font-semibold">Educational Initiative - Completed</p>
                </div>
              </div>
              <p className="text-gray-700 mb-6">
                Successfully conducted educational program that enhanced knowledge and awareness 
                through traditional wisdom and modern understanding. The program was well-received 
                by participants and created lasting impact in the community.
              </p>
              <div className="space-y-3 mb-6">
                <div className="flex items-center text-gray-600">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>Date: Previously conducted</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Clock className="h-4 w-4 mr-2" />
                  <span>Duration: Full day program</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span>Venue: Yogakshema Dhama</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Users className="h-4 w-4 mr-2" />
                  <span>Successfully completed with community participation</span>
                </div>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-blue-800 text-sm">
                  <strong>Event Highlights:</strong> The program featured interactive sessions, 
                  traditional teachings, and community engagement activities that left a positive 
                  impact on all participants.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default EventsPage;