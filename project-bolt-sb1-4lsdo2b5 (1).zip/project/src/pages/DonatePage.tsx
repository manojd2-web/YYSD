import React from 'react';
import { Heart, Building2, Sun, Utensils, Cog as Cow, CreditCard, Banknote, Smartphone, Globe } from 'lucide-react';

const DonatePage = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-amber-800 via-orange-700 to-amber-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Heart className="h-16 w-16 mx-auto mb-6 text-white" />
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Support Our Sacred Mission</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Your generous donations help us preserve ancient wisdom and serve the community
          </p>
        </div>
      </section>

      {/* Dhama Section */}
      <section id="dhama" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Support the <span className="text-amber-600">Sacred Dhama</span>
            </h2>
            <div className="w-24 h-1 bg-amber-600 mx-auto mb-8"></div>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg"
                alt="Sacred Dhama"
                className="rounded-2xl shadow-lg w-full h-96 object-cover"
              />
            </div>
            <div>
              <div className="flex items-center mb-6">
                <Building2 className="h-8 w-8 text-amber-600 mr-4" />
                <h3 className="text-3xl font-bold text-gray-900">Dhama Development</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Help us maintain and expand our sacred dhama facilities. Your contributions support 
                the upkeep of meditation halls, residential quarters, gardens, and infrastructure 
                that serves thousands of spiritual seekers annually.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Meditation hall maintenance and expansion</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Residential facilities for retreats</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Sacred gardens and peaceful spaces</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Library and study areas</span>
                </li>
              </ul>
              <button className="bg-amber-600 text-white px-8 py-4 rounded-full hover:bg-amber-700 transition-colors font-semibold text-lg">
                Donate for Dhama
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Surya Temple Section */}
      <section id="temple" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-orange-600">Surya Temple</span> Maintenance
            </h2>
            <div className="w-24 h-1 bg-orange-600 mx-auto mb-8"></div>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="flex items-center mb-6">
                <Sun className="h-8 w-8 text-orange-600 mr-4" />
                <h3 className="text-3xl font-bold text-gray-900">Temple Preservation</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Support the preservation and maintenance of our beautiful Surya Temple. Your donations 
                help maintain the sacred space, support daily rituals, and ensure the temple remains 
                a beacon of spiritual light for generations to come.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-orange-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Daily puja and ritual supplies</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-orange-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Temple maintenance and restoration</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-orange-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Festival celebrations and ceremonies</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-orange-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Priest support and training</span>
                </li>
              </ul>
              <button className="bg-orange-600 text-white px-8 py-4 rounded-full hover:bg-orange-700 transition-colors font-semibold text-lg">
                Donate for Temple
              </button>
            </div>
            <div className="order-1 lg:order-2">
              <img
                src="https://images.pexels.com/photos/3992828/pexels-photo-3992828.jpeg"
                alt="Surya Temple"
                className="rounded-2xl shadow-lg w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Annadana Section */}
      <section id="annadana" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-green-600">Annadana</span> - Food Service
            </h2>
            <div className="w-24 h-1 bg-green-600 mx-auto mb-8"></div>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg"
                alt="Annadana Food Service"
                className="rounded-2xl shadow-lg w-full h-96 object-cover"
              />
            </div>
            <div>
              <div className="flex items-center mb-6">
                <Utensils className="h-8 w-8 text-green-600 mr-4" />
                <h3 className="text-3xl font-bold text-gray-900">Sacred Food Service</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Annadana, the sacred act of feeding others, is one of the highest forms of service. 
                Your contributions help us provide nutritious, sattvic meals to visitors, students, 
                and those in need, embodying the principle that food is divine.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-green-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Daily meals for students and visitors</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-green-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Special feast during festivals</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-green-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Community kitchen maintenance</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-green-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Organic ingredients and supplies</span>
                </li>
              </ul>
              <button className="bg-green-600 text-white px-8 py-4 rounded-full hover:bg-green-700 transition-colors font-semibold text-lg">
                Donate for Annadana
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Care for Cows Section */}
      <section id="goshaale" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-blue-600">Care for Cows</span> - Goshala Support
            </h2>
            <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="flex items-center mb-6">
                <Cow className="h-8 w-8 text-blue-600 mr-4" />
                <h3 className="text-3xl font-bold text-gray-900">Goshala Maintenance</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Support our sacred goshala where we care for rescued cows with love and devotion. 
                Your donations help provide food, medical care, shelter, and a peaceful environment 
                for these gentle beings who are revered in our tradition.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Daily feed and nutrition for 50+ cows</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Veterinary care and medical supplies</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Shelter maintenance and improvements</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">Caretaker support and training</span>
                </li>
              </ul>
              <button className="bg-blue-600 text-white px-8 py-4 rounded-full hover:bg-blue-700 transition-colors font-semibold text-lg">
                Donate for Cow Care
              </button>
            </div>
            <div className="order-1 lg:order-2">
              <img
                src="https://images.pexels.com/photos/422218/pexels-photo-422218.jpeg"
                alt="Goshala Cow Care"
                className="rounded-2xl shadow-lg w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Donation Methods Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              <span className="text-purple-600">Donation</span> Methods
            </h2>
            <div className="w-24 h-1 bg-purple-600 mx-auto mb-8"></div>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Scan the QR code below to contribute to our sacred mission
            </p>
          </div>
          
          <div className="flex justify-center mb-12">
            <div className="bg-white rounded-2xl shadow-xl p-8 text-center max-w-md">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Scan to Donate</h3>
              <div className="bg-gray-50 p-6 rounded-xl mb-6">
                <img
                  src="/images/qr-code.png"
                  alt="Donation QR Code"
                  className="w-64 h-64 mx-auto object-contain"
                />
              </div>
              <p className="text-gray-700 mb-4">
                Scan this QR code with your mobile banking app or UPI app to make a secure donation
              </p>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <p className="text-purple-800 font-semibold text-sm">
                  Your contribution helps us maintain our sacred facilities and continue our spiritual mission
                </p>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <p className="text-gray-600 mb-6">
              For donation inquiries, alternative payment methods, or to set up recurring donations, please contact us directly.
            </p>
            <button className="bg-purple-600 text-white px-8 py-4 rounded-full hover:bg-purple-700 transition-colors font-semibold text-lg">
              Contact for Donations
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DonatePage;