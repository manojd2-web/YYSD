import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import YYSDPage from './pages/YYSDPage';
import EventsPage from './pages/EventsPage';
import CentersPage from './pages/CentersPage';
import ContactPage from './pages/ContactPage';
import DonatePage from './pages/DonatePage';
import LoginPage from './pages/LoginPage';
import SignUpPage from './pages/SignUpPage';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white">
        <Header />
        <Routes>
          <Route path="/" element={<Navigate to="/home" replace />} />
          <Route path="/home" element={<HomePage />} />
          <Route path="/yysd" element={<YYSDPage />} />
          <Route path="/events" element={<EventsPage />} />
          <Route path="/centers" element={<CentersPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/donate" element={<DonatePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignUpPage />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;