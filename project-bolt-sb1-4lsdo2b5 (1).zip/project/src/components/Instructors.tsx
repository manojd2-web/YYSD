import React from 'react';
import { Star, Award, Heart } from 'lucide-react';

const Instructors = () => {
  const instructors = [
    {
      name: 'Yoga Guru',
      title: 'Founder & Spiritual Guide',
      specialties: ['Traditional Hatha Yoga', 'Meditation', 'Pranayama', 'Spiritual Guidance'],
      experience: '15+ years',
      certification: 'Traditional Yoga Master, Spiritual Teacher',
      image: '/images/founder.png',
      bio: 'A dedicated practitioner and teacher of traditional yoga, bringing authentic teachings and spiritual wisdom to guide students on their journey of self-discovery and inner transformation.',
      quote: 'Yoga is the journey of the self, through the self, to the self. It is the path to discovering your true nature and finding peace within.'
    },
    {
      name: 'Senior Instructor',
      title: 'Advanced Yoga Teacher',
      specialties: ['Asana Practice', 'Breathing Techniques', 'Meditation'],
      experience: '10+ years',
      certification: 'Certified Yoga Instructor, Meditation Guide',
      image: '/images/instructor.png',
      bio: 'Dedicated to sharing the profound benefits of yoga practice, focusing on proper alignment, breath awareness, and the integration of yoga philosophy into daily life.',
      quote: 'Through consistent practice and dedication, yoga becomes a way of life that brings harmony to body, mind, and spirit.'
    },
  ];

  return (
    <section id="instructors" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Meet Our <span className="text-emerald-600">Teachers</span>
          </h2>
          <div className="w-24 h-1 bg-emerald-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
            Our experienced instructors are passionate about sharing the transformative 
            power of yoga. Each brings unique wisdom, expertise, and heart to guide 
            your practice with authenticity and care.
          </p>
        </div>

        {/* Instructors Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {instructors.map((instructor, index) => (
            <div
              key={index}
              className="bg-gray-50 rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 group"
            >
              <div className="relative">
                <img
                  src={instructor.image}
                  alt={instructor.name}
                  className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
              </div>

              <div className="p-8">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{instructor.name}</h3>
                    <p className="text-emerald-600 font-semibold">{instructor.title}</p>
                  </div>
                  <div className="flex items-center bg-emerald-100 px-3 py-1 rounded-full">
                    <Star className="h-4 w-4 text-emerald-600 mr-1" />
                    <span className="text-sm font-semibold text-emerald-600">Featured</span>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Award className="h-4 w-4 text-gray-600" />
                    <span className="text-sm text-gray-600">{instructor.experience} • {instructor.certification}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {instructor.specialties.map((specialty, idx) => (
                      <span
                        key={idx}
                        className="bg-white px-3 py-1 rounded-full text-sm text-gray-700 border border-gray-200"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>

                <p className="text-gray-700 mb-4 leading-relaxed">{instructor.bio}</p>

                <blockquote className="relative">
                  <div className="flex items-center gap-2 mb-2">
                    <Heart className="h-4 w-4 text-emerald-600" />
                    <span className="text-sm font-semibold text-gray-900">Philosophy</span>
                  </div>
                  <p className="text-gray-600 italic text-sm leading-relaxed pl-6 border-l-2 border-emerald-200">
                    "{instructor.quote}"
                  </p>
                </blockquote>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">
            Ready to Begin Your Journey?
          </h3>
          <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto">
            Our teachers are here to support and guide you every step of the way. 
            Book a class today and experience the Yogakshema difference.
          </p>
          <a
            href="#contact"
            className="inline-flex items-center bg-emerald-600 text-white px-8 py-4 rounded-full hover:bg-emerald-700 transition-colors duration-200 font-semibold text-lg"
          >
            Schedule Your First Class
          </a>
        </div>
      </div>
    </section>
  );
};

export default Instructors;