import React from 'react';
import { LayoutTemplate as Temple, TreePine, Users, BookOpen } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: Temple,
      title: 'Sacred Dhama & Temples',
      description: 'Experience our main dhama, visit the Surya Temple, and explore the pyramid meditation centers, each offering unique spiritual experiences and practices.'
    },
    {
      icon: TreePine,
      title: 'Goshala & Nature',
      description: 'Connect with nature through our goshaale (cow sanctuary), walk the sacred paths, and participate in courses that integrate yogic living with environmental consciousness.'
    },
    {
      icon: Users,
      title: 'Learning Centers',
      description: 'Join our main center in Belavadi, Bengaluru centers, or connect with student-run YYSD centers for continuous learning and spiritual growth.'
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Content */}
        <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-2xl p-8 md:p-12 mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-8 text-center">
            About Our <span className="text-blue-600">Spiritual Dhama</span>
          </h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          
          <div className="space-y-6 text-lg leading-relaxed text-gray-700">
            <p>
              Welcome to YOGAKSHEMA YOGA SAADHANA DHAMA, a sacred sanctuary dedicated to the practice and teaching of authentic yoga sadhana. Our dhama represents a complete spiritual ecosystem where ancient yogic wisdom is preserved and transmitted through various practices, facilities, and educational programs.
            </p>
            <p>
              Through our dhama, temples, goshala, pyramid meditation centers, and various spiritual programs, we offer a comprehensive path for seekers at all levels of their spiritual journey.
            </p>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white/90 backdrop-blur-sm rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:transform hover:-translate-y-2"
            >
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <feature.icon className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-blue-600 mb-4 text-center">{feature.title}</h3>
              <p className="text-gray-700 leading-relaxed text-center">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;