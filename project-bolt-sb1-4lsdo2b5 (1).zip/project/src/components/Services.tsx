import React from 'react';
import { Clock, Users, Zap, Sunrise, Moon, TreePine, Sparkles } from 'lucide-react';

const Services = () => {
  const classes = [
    {
      icon: Sunrise,
      title: 'Traditional Hatha Yoga',
      duration: '90 min',
      level: 'All Levels',
      price: 'Contact for pricing',
      description: 'Authentic Hatha yoga practice focusing on classical asanas, pranayama, and meditation techniques passed down through traditional lineages.',
      benefits: ['Physical strength & flexibility', 'Mental clarity', 'Spiritual awareness', 'Stress relief']
    },
    {
      icon: TreePine,
      title: 'Pranayama & Meditation',
      duration: '60 min',
      level: 'All Levels',
      price: 'Contact for pricing',
      description: 'Deep breathing practices and meditation techniques to calm the mind and awaken inner consciousness.',
      benefits: ['Inner peace', 'Emotional balance', 'Enhanced concentration', 'Spiritual growth']
    },
    {
      icon: Users,
      title: 'Group Classes',
      duration: '75 min',
      level: 'All Levels',
      price: 'Contact for pricing',
      description: 'Community-based yoga sessions that foster learning, sharing, and spiritual growth in a supportive environment.',
      benefits: ['Community connection', 'Shared learning', 'Motivation', 'Spiritual fellowship']
    },
    {
      icon: Moon,
      title: 'Private Sessions',
      duration: '90 min',
      level: 'All Levels',
      price: 'Contact for pricing',
      description: 'Personalized one-on-one sessions tailored to individual needs, goals, and spiritual aspirations.',
      benefits: ['Personalized guidance', 'Faster progress', 'Individual attention', 'Customized practice']
    },
    {
      icon: Sparkles,
      title: 'Spiritual Workshops',
      duration: '2-3 hours',
      level: 'All Levels',
      price: 'Contact for pricing',
      description: 'In-depth workshops on yoga philosophy, ancient texts, and spiritual practices for deeper understanding.',
      benefits: ['Deeper knowledge', 'Philosophical understanding', 'Spiritual insight', 'Traditional wisdom']
    },
    {
      icon: Zap,
      title: 'Online Classes',
      duration: '60-90 min',
      level: 'All Levels',
      price: 'Contact for pricing',
      description: 'Virtual yoga sessions bringing authentic teachings to students worldwide through online platforms.',
      benefits: ['Global accessibility', 'Flexible scheduling', 'Home practice', 'Consistent guidance']
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Our <span className="text-emerald-600">Classes</span>
          </h2>
          <div className="w-24 h-1 bg-emerald-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
            Choose from our diverse range of yoga classes designed to meet you wherever you are 
            on your wellness journey. Each class is thoughtfully crafted to provide both 
            physical benefits and spiritual growth.
          </p>
        </div>

        {/* Classes Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {classes.map((classItem, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group"
            >
              <div className="p-8">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-emerald-100 w-12 h-12 rounded-full flex items-center justify-center group-hover:bg-emerald-200 transition-colors">
                    <classItem.icon className="h-6 w-6 text-emerald-600" />
                  </div>
                  <span className="text-2xl font-bold text-emerald-600">{classItem.price}</span>
                </div>

                <h3 className="text-2xl font-bold text-gray-900 mb-2">{classItem.title}</h3>
                
                <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{classItem.duration}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    <span>{classItem.level}</span>
                  </div>
                </div>

                <p className="text-gray-700 mb-6 leading-relaxed">{classItem.description}</p>

                <div className="space-y-2 mb-6">
                  <h4 className="font-semibold text-gray-900">Benefits:</h4>
                  <ul className="space-y-1">
                    {classItem.benefits.map((benefit, idx) => (
                      <li key={idx} className="text-sm text-gray-600 flex items-center">
                        <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full mr-2"></div>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>

                <button className="w-full bg-emerald-600 text-white py-3 rounded-full hover:bg-emerald-700 transition-colors duration-200 font-semibold">
                  Book This Class
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center bg-white rounded-2xl shadow-lg p-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">
            New to Yoga?
          </h3>
          <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto">
            Join our beginner-friendly introduction workshop and discover the joy of yoga 
            in a supportive, non-judgmental environment.
          </p>
          <a
            href="#contact"
            className="inline-flex items-center bg-emerald-600 text-white px-8 py-4 rounded-full hover:bg-emerald-700 transition-colors duration-200 font-semibold text-lg"
          >
            Book Free Trial Class
          </a>
        </div>
      </div>
    </section>
  );
};

export default Services;