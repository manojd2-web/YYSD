import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown, Heart, User } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const donateItems = [
    { label: 'Dhama', href: '/donate#dhama' },
    { label: 'Surya Temple', href: '/donate#temple' },
    { label: 'Annadana', href: '/donate#annadana' },
    { label: 'Care for Cows', href: '/donate#goshaale' },
  ];

  const menuItems = [
    {
      label: 'HOME',
      href: '/home',
      dropdown: [
        { label: 'About US', href: '/home#about-us' },
        { label: 'About Founder', href: '/home#about-founder' },
      ]
    },
    {
      label: 'YYSD',
      href: '/yysd',
      dropdown: [
        { label: 'Dhama', href: '/yysd#dhama' },
        { label: 'Surya Temple', href: '/yysd#temple' },
        { label: 'Gokulam Goshale', href: '/yysd#goshaale' },
        { label: 'Pyramid - Shree Maa Dhyana Mandira', href: '/yysd#pyramid' },
        { label: 'Healing Walkway', href: '/yysd#walking' },
        { label: 'Yoga Teachers Training Camps (YTTC)', href: '/yysd#yttc' },
      ]
    },
    {
      label: 'EVENTS',
      href: '/events',
      dropdown: [
        { label: 'Upcoming Events', href: '/events#upcoming' },
        { label: 'Past Events', href: '/events#past' },
      ]
    },
    {
      label: 'CENTERS',
      href: '/centers',
      dropdown: [
        { label: 'Main Center (Belavadi)', href: '/centers#main-center' },
        { label: 'Bengaluru Centers', href: '/centers#bengaluru' },
        { label: 'Centers run by YYSD Students', href: '/centers#student-centers' },
      ]
    },
    { label: 'CONTACT US', href: '/contact' },
  ];

  return (
    <header className="bg-white/95 backdrop-blur-sm shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col py-4 gap-4">
          {/* Top Row */}
          <div className="flex flex-col lg:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <img 
                src="/images/logo.png" 
                alt="Yogakshema Logo" 
                className="h-12 w-auto"
              />
              <div className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                YOGAKSHEMA YOGA SAADHANA DHAMA
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              {/* Donate Dropdown */}
              <div className="relative group">
                <Link
                  to="/donate"
                  className="flex items-center gap-2 px-4 py-2 bg-white/80 border border-gray-200 rounded-full hover:bg-gradient-to-r hover:from-amber-600 hover:to-orange-600 hover:text-white transition-all duration-300"
                >
                  <Heart className="w-4 h-4" />
                  Donate
                  <ChevronDown className="w-3 h-3 group-hover:rotate-180 transition-transform" />
                </Link>
                <div className="absolute top-full left-0 mt-2 bg-white rounded-2xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 min-w-48 z-50">
                  {donateItems.map((item, index) => (
                    <Link
                      key={index}
                      to={item.href}
                      className="block px-5 py-3 text-gray-700 hover:bg-gradient-to-r hover:from-amber-600 hover:to-orange-600 hover:text-white transition-all duration-300 first:rounded-t-2xl last:rounded-b-2xl"
                    >
                      {item.label}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Auth Section */}
              <div className="flex items-center gap-2 px-4 py-2 bg-white/80 border border-gray-200 rounded-full hover:bg-gradient-to-r hover:from-amber-600 hover:to-orange-600 hover:text-white transition-all duration-300">
                <User className="w-4 h-4" />
                <Link to="/login" className="hover:underline">Login</Link>
                <span>|</span>
                <Link to="/signup" className="hover:underline">Sign Up</Link>
              </div>
            </div>
          </div>

          {/* Bottom Row - Navigation */}
          <div className="flex justify-center lg:justify-end">
            <nav className="bg-white/90 rounded-full px-2 py-2 shadow-lg">
              <ul className="hidden lg:flex items-center">
                {menuItems.map((item, index) => (
                  <React.Fragment key={index}>
                    <li className="relative group">
                      <Link
                        to={item.href}
                        className="flex items-center gap-1 px-5 py-3 text-gray-700 font-medium hover:bg-gradient-to-r hover:from-blue-600 hover:to-purple-600 hover:text-white rounded-full transition-all duration-300 whitespace-nowrap"
                      >
                        {item.label}
                        {item.dropdown && (
                          <ChevronDown className="w-3 h-3 group-hover:rotate-180 transition-transform" />
                        )}
                      </Link>
                      {item.dropdown && (
                        <div className="absolute top-full left-0 mt-2 bg-white rounded-2xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 min-w-56 z-50">
                          {item.dropdown.map((dropItem, dropIndex) => (
                            <Link
                              key={dropIndex}
                              to={dropItem.href}
                              className="block px-5 py-3 text-gray-700 hover:bg-gradient-to-r hover:from-blue-600 hover:to-purple-600 hover:text-white transition-all duration-300 first:rounded-t-2xl last:rounded-b-2xl"
                              onClick={() => {
                                // If it's a hash link, scroll to section after navigation
                                if (dropItem.href.includes('#')) {
                                  setTimeout(() => {
                                    const sectionId = dropItem.href.split('#')[1];
                                    const element = document.getElementById(sectionId);
                                    if (element) {
                                      element.scrollIntoView({ behavior: 'smooth' });
                                    }
                                  }, 100);
                                }
                              }}
                            >
                              {dropItem.label}
                            </Link>
                          ))}
                        </div>
                      )}
                    </li>
                    {index < menuItems.length - 1 && (
                      <li className="flex items-center">
                        <span className="text-gray-400 mx-2">|</span>
                      </li>
                    )}
                  </React.Fragment>
                ))}
              </ul>

              {/* Mobile Menu Button */}
              <button
                className="lg:hidden p-2"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? (
                  <X className="h-6 w-6 text-gray-800" />
                ) : (
                  <Menu className="h-6 w-6 text-gray-800" />
                )}
              </button>
            </nav>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="lg:hidden bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl mt-2">
              <div className="py-4 space-y-2">
                {menuItems.map((item, index) => (
                  <div key={index}>
                    <Link
                      to={item.href}
                      className="block px-6 py-3 text-gray-700 hover:bg-gradient-to-r hover:from-blue-600 hover:to-purple-600 hover:text-white transition-all duration-300"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {item.label}
                    </Link>
                    {item.dropdown && (
                      <div className="pl-4 space-y-1">
                        {item.dropdown.map((dropItem, dropIndex) => (
                          <Link
                            key={dropIndex}
                            to={dropItem.href}
                            className="block px-6 py-2 text-sm text-gray-600 hover:text-blue-600 transition-colors"
                            onClick={() => {
                              setIsMenuOpen(false);
                              // If it's a hash link, scroll to section after navigation
                              if (dropItem.href.includes('#')) {
                                setTimeout(() => {
                                  const sectionId = dropItem.href.split('#')[1];
                                  const element = document.getElementById(sectionId);
                                  if (element) {
                                    element.scrollIntoView({ behavior: 'smooth' });
                                  }
                                }, 100);
                              }
                            }}
                          >
                            {dropItem.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;