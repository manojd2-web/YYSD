import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Devoted Student',
      role: 'Long-time Practitioner',
      image: '/images/testimonial.jpg',
      rating: 5,
      text: 'The authentic teachings at Yogakshema have brought profound transformation to my life. The traditional approach and spiritual guidance have helped me find inner peace and true understanding of yoga.',
      highlight: 'Profound spiritual transformation through authentic teachings'
    },
    {
      name: 'Grateful Practitioner',
      role: 'Yoga Enthusiast',
      image: '/images/testimonial.jpg',
      rating: 5,
      text: 'The traditional Hatha yoga practices and meditation techniques have brought balance and clarity to my daily life. The wisdom shared here is truly authentic and transformative.',
      highlight: 'Balance and clarity through traditional practices'
    },
    {
      name: 'Dedicated Student',
      role: 'Spiritual Seeker',
      image: '/images/testimonial.jpg',
      rating: 5,
      text: 'Yogakshema has provided me with genuine spiritual guidance and authentic yoga knowledge. The community here is supportive and the teachings are rooted in traditional wisdom.',
      highlight: 'Genuine spiritual guidance and authentic knowledge'
    },
    {
      name: 'Committed Practitioner',
      role: 'Yoga Student',
      image: '/images/testimonial.jpg',
      rating: 5,
      text: 'The personalized attention and traditional approach to yoga practice has helped me develop a deeper understanding of yoga philosophy and its practical applications in life.',
      highlight: 'Deeper understanding through traditional approach'
    },
    {
      name: 'Inspired Student',
      role: 'Wellness Seeker',
      image: '/images/testimonial.jpg',
      rating: 5,
      text: 'The pranayama and meditation sessions have brought tremendous peace and mental clarity. The authentic teachings and spiritual atmosphere make this a truly special place for learning.',
      highlight: 'Tremendous peace through authentic teachings'
    },
    {
      name: 'Thankful Student',
      role: 'Life-long Learner',
      image: '/images/testimonial.jpg',
      rating: 5,
      text: 'Yogakshema has been instrumental in my spiritual journey. The traditional teachings, combined with practical guidance, have helped me integrate yoga principles into every aspect of my life.',
      highlight: 'Instrumental in spiritual journey and life integration'
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            What Our Students <span className="text-emerald-600">Say</span>
          </h2>
          <div className="w-24 h-1 bg-emerald-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
            Don't just take our word for it. Hear from our amazing community of practitioners 
            who have found transformation, healing, and joy through their yoga journey with us.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 relative overflow-hidden group"
            >
              {/* Quote Icon */}
              <div className="absolute top-4 right-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Quote className="h-12 w-12 text-emerald-600" />
              </div>

              {/* Rating */}
              <div className="flex items-center mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>

              {/* Highlight */}
              <div className="bg-emerald-50 border-l-4 border-emerald-600 p-3 mb-6 rounded-r-lg">
                <p className="text-emerald-800 font-semibold text-sm">
                  "{testimonial.highlight}"
                </p>
              </div>

              {/* Testimonial Text */}
              <p className="text-gray-700 leading-relaxed mb-6 relative z-10">
                {testimonial.text}
              </p>

              {/* Author */}
              <div className="flex items-center">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover mr-4 border-2 border-emerald-100"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                  <p className="text-emerald-600 text-sm">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Stats Section */}
        <div className="bg-white rounded-2xl shadow-lg p-12">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-emerald-600 mb-2">500+</div>
              <div className="text-gray-600">Happy Students</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-emerald-600 mb-2">1000+</div>
              <div className="text-gray-600">Classes Taught</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-emerald-600 mb-2">5</div>
              <div className="text-gray-600">Years of Excellence</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-emerald-600 mb-2">98%</div>
              <div className="text-gray-600">Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;